<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeaturedBanner extends Model
{
    //
}
