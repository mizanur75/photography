<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Otp;
use App\Models\User;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Input;
use Validator;
use Session;
use DB;
use JWTAuth;

class ApiRegisterLoginController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' =>
            ['login','registerOtp','resendOtp','register','']
        ]);
    }

    //Registration with otp
    public function registerOtp(Request $request)
    {
        //--- Validation Section
        $rules = [
            'phone' => 'required|unique:users',
            'password' => 'required|confirmed'
        ];
        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }

        //--- OTP Section
        $otp = mt_rand(1000, 9999);
        $phone = $request->phone;
        try {
            $smsUrl = "http://gosms.xyz/api/v1/sendSms?username=medylife&password=Vu3wq8e7j7KqqQN&number=(" . $phone . ")&sms_content=Your%20OTP%20is:%20" . $otp . "&sms_type=1&masking=non-masking";

            //otp table

            $otp_code = new Otp();
            $otp_code->name = $request->name;
            $otp_code->password = $request->password;
            $otp_code->email = $request->email;
            $otp_code->phone = $request->phone;
            $otp_code->otp = $otp;
            $otp_code->save();

            //--- Send api sms request

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $smsUrl);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_POST, false);
            curl_exec($curl); //response output
            curl_close($curl);

            return response()->json(['status' => 'success','message'=>'Otp sent successfully'], 200);

        } catch (\Exception $exception) {

            return response()->json($exception->getMessage());

        }
    }

    //Registration  otp resend
    public function resendOtp(Request $request){

        //--- Validation Section
        $rules = [
            'phone' => 'required|unique:users',
        ];
        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }

        $registration_info = Otp::where('phone',$request->phone)->latest()->first();

        if($registration_info){
            //--- OTP Section
            $otp = mt_rand(1000, 9999);

            $phone = $request->phone;
            try {
                $smsUrl = "http://gosms.xyz/api/v1/sendSms?username=medylife&password=Vu3wq8e7j7KqqQN&number=(" . $phone . ")&sms_content=Your%20OTP%20is:%20" . $otp . "&sms_type=1&masking=non-masking";

                //--- Send api sms request

                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL, $smsUrl);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($curl, CURLOPT_POST, false);
                curl_exec($curl); //response output
                curl_close($curl);

                //otp table update

                $registration_info->update([
                    'otp' => $otp,
                ]);

                return response()->json(['status' => 'success','message'=>'Otp resend successfully'], 200);
            }
            catch (\Exception $exception){
                return response()->json($exception->getMessage());
            }
        }
        else{
            return response()->json(['status' => 'warning','message'=>'User not found'], 200);
        }

    }

    //Registration  store
    public function register(Request $request){

        //--- Validation Section
        $rules = [
            'phone' => 'required|unique:users',
            'otp' => 'required',
        ];
        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }

        $registration_info = Otp::where('phone',$request->phone)
            ->where('otp',$request->otp)->latest()->first();

        try{
            if($registration_info){

                //Registration
                $password = $registration_info->password;
                $user = new User();
                $user -> name = $registration_info->name;
                $user -> email = $registration_info->email;
                $user -> phone = $registration_info->phone;
                $user -> password = bcrypt($password);
                $token = md5(time().$registration_info->name.$registration_info->email);
                $user -> verification_link = $token;
                $user -> affilate_code = md5($registration_info->name.$registration_info->email);;
                $user->save();

                //delete Otp data
                $delete_datas = Otp::where('phone',$registration_info->phone)->get();
                foreach($delete_datas as $delete_data){
                    $delete_data->delete();
                }

                //Notification
                $notification = new Notification();
                $notification->user_id = $user->id;
                $notification->save();

                Auth::guard('web')->login($user);

                $token = JWTAuth::fromUser($user);

                return response()->json(compact('user','token'),201);
            }
            else{
                return response()->json(['status' => 'error','message'=>'Registration failed'], 401);
            }
        }
        catch (\Exception $exception){
            return response()->json($exception->getMessage());
        }

    }

    public function login(Request $request)
    {

        $credentials = $request->only('phone', 'password');

        if ($token = $this->guard()->attempt($credentials)) {
            return $this->respondWithToken($token);
        }

        return response()->json(['status' => 'error','message'=>'Unauthorized'], 401);
    }

    /**
     * Get the authenticated User
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function me()
    {
        try{
            return response()->json($this->guard()->user());
        }
        catch (\Exception $exception){
            return response()->json($exception->getMessage());
        }

    }

    /**
     * Log the user out (Invalidate the token)
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        $this->guard()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken($this->guard()->refresh());
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => $this->guard()->factory()->getTTL() * 60
        ]);
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\Guard
     */
    public function guard()
    {
        return Auth::guard();
    }


}